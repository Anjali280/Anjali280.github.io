import React, { useEffect, useState } from "react";
import ProductCard from "./ProductCard";

function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const res = await fetch(
      "https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products"
    );
    const resObj = await res.json();

    setProducts(resObj.data);
  };
  return (
    <div>
      {products.map((elem, index) => {
        return <ProductCard key={index} product={elem} />;
      })}
    </div>
  );
}

export default Products;
