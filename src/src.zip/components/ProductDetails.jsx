import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function ProductDetails() {
  const { id } = useParams();
  const [products, setProducts] = useState([]);
  const [product, setProduct] = useState({});
  //console.log(products);

  useEffect(() => {
    fetchData();
    console.log("fetch called");

    const productObj = products.filter((elem) => {
      console.log(elem.id, id);
      return elem.id === Number(id);
    });
    setProduct(productObj[0]);
    console.log(productObj);
  }, [product]);

  const fetchData = async () => {
    const res = await fetch(
      "https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products"
    );
    const resObj = await res.json();

    setProducts(resObj.data);
  };

  return (
    <div>
      <h3>{product.title}</h3>
      <img src={product.image} alt={product.title} />
      <h4>{product.price}</h4>
      <p>{product.brand}</p>
      <p>{product.category}</p>
    </div>
  );
}

export default ProductDetails;
